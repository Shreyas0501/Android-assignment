package com.taskmanagement

import androidx.fragment.app.Fragment

class TaskDetailsFragment: Fragment(R.layout.fragment_task_details) {
}