package com.example.contacts_application2

interface FragmentActionListener {
    fun onAddNewContactFragment()
}