package com.dogbreeds

data class DogBreedProperty(
    val title: String,
    var value: String
)
